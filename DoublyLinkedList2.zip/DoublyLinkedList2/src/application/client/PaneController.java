package application.client;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.StringTokenizer;

import javafx.scene.layout.Pane;

public class PaneController {
    private Pane mainPane;
    private MedClient medClient;
    private Diagnose diagnose;
    private DatabaseHandler databaseHandler;
    
    public PaneController() {
		mainPane = new Pane();
		medClient = new MedClient(this);
		/*if(check() == true) {
			databaseHandler = new DatabaseHandler(this);
		}*/
		
		diagnose = new Diagnose(this);
		
		// Set the initial pane to MedClient
		mainPane.getChildren().add(medClient.getPane());
	}
    
    
    public boolean check()
	  {
		  boolean ch = false;
		  Integer num = readText("data/server/Info.txt");
		  if( num != null)
		  {
			  ch= true;
		  }
		  return ch;
	  }
    
    public int readText(String path) {
    	int percent = 0;
    	
    	File f = new File(path);
    	try 
    	{
    		
			Scanner sc = new Scanner(f);
			while(sc.hasNext())
			{
				String line = sc.nextLine();
				StringTokenizer tokenizer = new StringTokenizer(line, " ");
				String name = tokenizer.nextToken();
				String age = tokenizer.nextToken();
				String sickness = tokenizer.nextToken();
				String otherSickness = tokenizer.nextToken();
				
				String result = tokenizer.nextToken();
				percent = (int) Double.parseDouble(result); 
				System.out.println(percent);
			}
			sc.close();
		} 
    	catch (FileNotFoundException e) 
    	{
			e.printStackTrace();
		}
    	
    	return percent;
    } 
    
    public void switchToDatabase() {
    			mainPane.getChildren().clear();
			      mainPane.getChildren().add(databaseHandler.returnpane());
    }
    
    public void switchToDiagnose() {
    			mainPane.getChildren().clear();
    		      mainPane.getChildren().add(diagnose.getPane());
    }
    
    public void switchToMedClient() {
				mainPane.getChildren().clear();
			      mainPane.getChildren().add(medClient.getPane());
	}
    

    
    public Pane getPane() {
		return mainPane;
	}
}
