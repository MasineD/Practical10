package application.client;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Scanner;
import java.util.Set;

/**
 * Heap data structure with ArrayList as the underlying data structure
 */
public class Heap 
{
	ArrayList<HeapNode> heap;
	public String[] arr;
	ArrayList<String> details;
	
	public Heap() 
	{
		heap = new ArrayList<>();
		details = new ArrayList<>();
	}
	public int parent(int x)
	{
		return (x-1) / 2; 
	}
	public int leftChild(int x)
	{
		return 2*x + 1;
	}
	public int rightChild(int x)
	{
		return 2*x + 2;
	}
	public boolean hasLeft(int x)
	{
		return leftChild(x) < heap.size(); 
	}
	public boolean hasRight(int x)
	{
		return rightChild(x) < heap.size(); 
	}
	public int size()
	{
		return heap.size();
	}
	public boolean isEmpty() 
	{
		return (size() == 0);
	}
	public void swap(ArrayList<HeapNode> hT, int i, int j) 
    {
        HeapNode temp = hT.get(i);
        hT.set(i, hT.get(j));
        hT.set(j, temp);
    }

    public void upheap(ArrayList<HeapNode> hT, int i) 
    {
        while (i > 0 && hT.get(i).key > hT.get(parent(i)).key) 
        {
            swap(hT, i, parent(i));
            i = parent(i);
        }
    }
    public void downheap(ArrayList<HeapNode> hT, int i) 
    {
        int size = hT.size();
        int largest = i;

        if (leftChild(i) < size && hT.get(leftChild(i)).key > hT.get(largest).key)
        {
        	largest = leftChild(i);
        }
        if (rightChild(i) < size && hT.get(rightChild(i)).key > hT.get(largest).key)
        {
        	largest = rightChild(i);
        }
        if (largest != i)
        {
            swap(hT, i, largest);
            downheap(hT, largest);
        }
    }
    public void insert(ArrayList<HeapNode> hT, int newNum, String info) 
    {
        HeapNode newNode = new HeapNode(newNum);
        
        // Assigning a value to a specific key
        newNode.values[0] = info;
        
        hT.add(newNode);
        for(int i = hT.size() / 2 - 1; i >= 0; i--) 
        {
        	//Restoring the heap-order property
            upheap(hT, i);
            downheap(hT, i);
        }
    }

    public void deleteNode(ArrayList<HeapNode> hT, int num) 
    {
        int size = hT.size();
        int i;
        for (i = 0; i < size; i++) 
        {
            if (num == hT.get(i).key)
                break;
        }

        HeapNode temp = hT.get(i);
        hT.set(i, hT.get(size - 1));
        hT.set(size - 1, temp);

        hT.remove(size - 1);
        for (int j = size / 2 - 1; j >= 0; j--) 
        {
        	//Restoring the heap-order property
            upheap(hT, j);
            downheap(hT, j);
        }
    }
    public void display(ArrayList<HeapNode> array) 
    {
    	System.out.println("~~~~~~~~~~~~~~~DISPLAY~~~~~~~~~~~~~");
        for (HeapNode node : array) 
        {
        	for(int i = 0; i< node.values.length; i++) 
        	{
        		String info = node.values[i];
        		if(info != null) 
        		{
        			System.out.println("Key: " + node.key + " | Values: " + info);
        		}
        	}
        }
    }
    //Method to read the treatment data from a file
    public void readFile(String filePath, ArrayList<String> arrList, ArrayList<HeapNode> nodeList) 
    {
    	File f = new File(filePath);
    	try 
    	{
    		
			Scanner sc = new Scanner(f);
			sc.useDelimiter("\\n\\s*\\n");
			while(sc.hasNext())
			{
				arrList.add(sc.next().trim());
			}
			arr = arrList.toArray(new String[1000]);
			int[] _arr1 = {7, 23, 37, 53, 67, 83, 95};
			//Inserting the data directly into the heap
	        for(int i =0; i < _arr1.length;i++) 
	        {
	        	if(arr[i] != null) 
	        	{
	        		insert(nodeList, _arr1[i], arr[i]);
	        	}
	        }
			sc.close();
		} 
    	catch (FileNotFoundException e) 
    	{
			e.printStackTrace();
		}
    }
    /*Implementing the A* algorithm to search for a key
    public int aStarSearch(ArrayList<Node> heap, int target) 
    {
        if (heap.isEmpty()) return -1;

        PriorityQueue<Entry> openSet = new PriorityQueue<>(Comparator.comparingInt(n -> n.cost + n.heuristic));
        Set<Integer> visited = new HashSet<>();

        // Start from root (index 0)
        openSet.add(new Entry(0, 0, heuristic(heap.get(0).key, target)));

        while (!openSet.isEmpty()) {
            Entry current = openSet.poll();
            int index = current.index;

            if (heap.get(index).key == target) {
                return index;
            }

            visited.add(index);

            // Check left and right children (heap neighbors)
            int left = leftChild(index);
            int right = rightChild(index);if (hasLeft(index) && !visited.contains(left)) {
                openSet.add(new Entry(left, current.cost + 1, 
                        heuristic(heap.get(left).key, target)));
                }

                if (hasRight(index) && !visited.contains(right)) {
                    openSet.add(new Entry(right, current.cost + 1, 
                        heuristic(heap.get(right).key, target)));
                }
            }
            return -1; // Key not found
        }

        private int heuristic(int value, int target) {
            return Math.abs(value - target);
        }*/
    
 // Modified A* Search to find keys within ±5 of target
    public List<Integer> aStarSearchRange(ArrayList<HeapNode> heap, int target) {
        List<Integer> foundIndices = new ArrayList<>();
        if (heap.isEmpty()) return foundIndices;

        PriorityQueue<Entry> openSet = new PriorityQueue<>(Comparator.comparingInt(n -> n.cost + n.heuristic));
        Set<Integer> visited = new HashSet<>();

        // Start from root (index 0)
        openSet.add(new Entry(0, 0, heuristic(heap.get(0).key, target)));

        while (!openSet.isEmpty()) {
        	Entry current = openSet.poll();
            int index = current.index;
            int currentKey = heap.get(index).key;// Check if current key is within ±5 of target
            if (Math.abs(currentKey - target) <= 5) {
                foundIndices.add(index);
            }

            visited.add(index);

            // Check left and right children (heap neighbors)
            int left = leftChild(index);
            int right = rightChild(index);

            if (hasLeft(index) && !visited.contains(left)) {
                openSet.add(new Entry(left, current.cost + 1, 
                    heuristic(heap.get(left).key, target)));
            }

            if (hasRight(index) && !visited.contains(right)) {
                openSet.add(new Entry(right, current.cost + 1, 
                    heuristic(heap.get(right).key, target)));
            }
        }
        return foundIndices;
    }
    private int heuristic(int value, int target) {
        // Modified heuristic to prioritize nodes closer to target range
        int distance = Math.abs(value - target);
        return distance <= 5 ? 0 : distance - 5;
    }
}